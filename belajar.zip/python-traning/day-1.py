a = int(input("masukan bilangan pertama : "))
b= int(input("masukan bilangan ke dua : "))
c = 24

d = (a * 3 + b)
e = (d * c)
print("ini adalah nilai nya : ",e)