// kode variable

// penamaan variable bisa di tuliskan menjadi 3 macam yaitu : 
let bisaDiUbah = "data"             // let ini memiliki fungsi yang di mana isi dari variable nya bisa diubah 
const tidakBisaDiUbah = "data"      //const ini memiliki fungsi yang di mana variable nya tidak bisa diubah
var bisaDiUbah2 = "data"            // var ini merupakan penamaan variable yang fungsinya bisa merubah nilai variable, tatapi var ini merupakan cara lama.
                

// type data pada variable
let String = "ini String"   // type data String
let int = 2009              // type data Int
let Double = 99.9           // type data Double
let Boolean = true          // type data Boolean
let kosong = null           // nilai kosong
let belumDiBeriNilai        // nilai belum di berikan (Undefined)

// pemanggilan variable
let nama ="zaidan rezkyando"
let umur = 16
let alamat = "gg.tawon"
console.log(`hai perkenalkan nama saya adalah ${nama} dan umur saya adalah ${umur} dan juga alamat saya adalah ${alamat}`)
// gunakan console.log untuk melakukan pengoutputan, masih ada cara lain dan ini salah satunya


// Matematika / perhitungan dalam JavaScript
let nilai1 = 12
let nilai2 = 20
console.log(nilai1 + nilai2); //tambah
console.log(nilai1 - nilai2); //kurang
console.log(nilai1 / nilai2); //bagi
console.log(nilai1 * nilai2); //kali
console.log(nilai1 % nilai2); //hasil bagi (Modulus)

